---
title: The Golden Apple Tree and the Nine Peahens -- The Witch.
description: The conclusion of the Prince and the Peahen
date: 2018-10-04
series: "swan-wives"
part: 4
tags: second tag
---

Next day, when the dragon went out, the king's son came, and the queen told him all she had learned from the dragon. Then the king's son went away to the mountain and found the old woman, and entered her house. 

She greeted, "God help you too, my son! What do you wish?"

"I should like to serve you," said the king's son. Then the old woman said, "Well, my son, if you keep my mare safe for three days and three nights, I will give you the best horse, and you can choose him yourself. But if you do not keep the mare safe, you shall lose your head."

Then she led him into the courtyard, where all around stakes were ranged. Each of them had on it a man's head, except one stake, which had no head on it, and shouted incessantly, "Oh, grandmother, give me a head!"

The old woman showed all this to the prince, and said, "Look here! All these were heads of those who tried to keep my mare, and they have lost their heads for their pains!"

But the prince was not a bit afraid, so he stayed to serve the old woman. When the evening came he mounted the mare and rode her into the field, and the foal followed. He sat still on her back, having made up his mind not to dismount, that he might be sure of her. But before midnight he slumbered a little, and when he awoke he found himself sitting on a rail and holding the bridle in his hand.

Then he was greatly alarmed, and went instantly to look about to find the mare, and whilst looking for her, he came to a piece of water. When he saw the water he remembered the little fish, and took the scale from the handkerchief and rubbed it a little. Then immediately the little fish appeared and said, "What is the matter, my half-brother?"

And he replied, "The mare of the old woman ran away whilst under my charge, and now I do not know where she is!"

And the fish answered, "Here she is, turned to a fish, and the foal to a smaller one. But strike once upon the water with the bridle and cry out, 'Hey! mare of the old woman!'"

The prince did as he was told, and immediately the mare came, with the foal, out of the water to the shore. Then he put on her the bridle and mounted and rode away to the old woman's house, and the foal followed. When he got there the old woman gave him his breakfast. She, however, took the mare into the stable and beat her with a poker, saying, "Why did you not go down among the fishes, you cursed mare?"

And the mare answered, "I have been down to the fishes, but the fish are his friends, and they told him about me."

Then the old woman said, "Then go among the foxes!"

When evening came the king's son mounted the mare and rode to the field, and the foal followed the mare. Again he sat on the mare's back until near midnight, when he fell asleep as before. When he awoke, he found himself riding on the rail and holding the bridle in his hand.

So he was much frightened, and went to look after the mare. As he went, he remembered the words the old woman had said to the mare, and he took from the handkerchief the fox's hair and rubbed it a little between his fingers. All at once the fox stood before him, and asked, "What is the matter, half-brother?"

And he said, "The old woman's mare has run away, and I do not know where she can be."

Then the fox answered, "Here she is with us. She has turned into a fox, and the foal into a cub. But strike once with the bridle on the earth and cry out, 'Hey! you old woman's mare!'"

So the king's son struck with the bridle on the earth and cried, "Hey! old woman's mare!" and the mare came and stood, with her foal, near him.

He put on the bridle, and mounted and rode off home, and the foal followed the mare. When he arrived the old woman gave him his breakfast, but took the mare into the stable and beat her with the poker, crying, "To the foxes, cursed one! To the foxes!"

And the mare answered, "I have been with the foxes, but they are his friends, and told him I was there!"

Then the old woman cried, "If that is so, you must go among the wolves!"

When it grew dark again, the king's son mounted the mare and rode out to the field, and the foal galloped by the side of the mare. Again he sat still on the mare's back till about midnight, when he grew very sleepy and fell into a slumber, as on the former evenings, and when he awoke he found himself riding on the rail, holding the bridle in his hand, just as before.

Then, as before, he went in a hurry to look after the mare. As he went, he remembered the words the old woman had said to the mare, and took the wolf's hair from the handkerchief and rubbed it a little. Then the wolf came up to him and asked, "What is the matter, half-brother?"

And he answered, "The old woman's mare has run away, and I cannot tell where she is."

The wolf said, "Here she is with us. She has turned herself into a wolf, and the foal into a wolf's cub. Strike once with the bridle on the earth and cry out, 'Hey! old woman's mare!'"

And the king's son did so, and instantly the mare came again and stood with the foal beside him. So he bridled her, and galloped home, and the foal followed. When he arrived the old woman gave him his breakfast, but she led the mare into the stable and beat her with the poker, crying, "To the wolves, I said, miserable one!"

And the mare answered, "I have been to the wolves, but they are his friends, and told him all about me!"

Then the old woman came out of the stable, and the king's son said to her, "Eh! grandmother, I have served you honestly. Now give me what you promised me."

And the old woman answered, "My son, what is promised must be fulfilled. So look here. Here are the twelve horses. Choose which you like!"

And the prince said, "Why should I be too particular? Give me only that leprous horse in the corner! Fine horses are not fitting for me!"

But the old woman tried to persuade him to choose another horse, saying, "How can you be so foolish as to choose that leprous thing whilst there are such very fine horses here?"

But he remained firm by his first choice, and said to the old woman, "You ought to give me which I choose, for so you promised."

So, when the old woman found she could not make him change his mind, she gave him the scabby horse, and he took leave of her, and went away, leading the horse by the halter.

When he came to a forest he curried and rubbed down the horse, when it shone as bright as gold. He then mounted, and the horse flew as quickly as a bird, and in a few seconds brought him to the dragon's palace.

The king's son went in and said to the queen, "Get ready as soon as possible!" She was soon ready, when they both mounted the horse, and began their journey home. Soon after, the dragon came home, and when he saw the queen had disappeared, said to his horse, "What shall we do? Shall we eat and drink first, or shall we pursue them at once?"

The horse answered, "Whether we eat and drink or not, it is all one. We shall never reach them."

When the dragon heard that, he got quickly on his horse and galloped after them. When they saw the dragon following them, they pushed on quicker, but their horse said, "Do not be afraid! There is no need to run away."

In a very few moments the dragon came very near to them, and his horse said to their horse, "For God's sake, my brother, wait a moment! I shall kill myself running after you!"

Their horse answered, "Why are you so stupid as to carry that monster? Fling your heels up and throw him off, and come along with me!"

When the dragon's horse heard that, he shook his head angrily and flung his feet high in the air, so that the dragon fell off and brake in pieces, and his horse came up to them.

Then the queen mounted him and returned with the king's son happily to her kingdom, where they reigned together in great prosperity until the day of their death.

*Source*: Csedomille Mijatovies, *Serbian Folk-Lore: Popular Tales* (London: W.Isbister and Company, 1874), pp. 43-58. Taken from here: https://sites.pitt.edu/~dash/swan.html



---
title: Evil Husbands & Their Curious Wives -- The Devil
description: An Italian edition of Bluebeard
date: 2018-08-24
series: "evil-husbands-curious-wives"
part: 3
tags:
  - second tag
  - posts with two tags
---
Our series concludes with a variant of Bluebeard from Venice, Italy.

## How the Devil Married Three Sisters

Once upon a time the devil was seized with a desire to marry. He therefore left hell, took the form of a handsome young man, and built a fine large house. When it was completed and furnished in the most fashionable style he introduced himself to a family where there were three pretty daughters, and paid his addresses to the eldest of them. The handsome man pleased the maiden, her parents were glad to see a daughter so well provided for, and it was not long before the wedding was celebrated.

When he had taken his bride home, he presented her with a very tastefully arranged bouquet, led her through all the rooms of the house, and finally to a closed door. 

"The whole house is at your disposal," said he, "only I must request one thing of you; that is, that you do not on any account open this door."

Of course the young wife promised faithfully; but equally, of course, she could scarcely wait for the moment to come when she might break her promise. When the devil had left the house the next morning, under pretence of going hunting, she ran hastily to the forbidden door, opened it, and saw a terrible abyss full of fire that shot up towards her, and singed the flowers on her bosom. 

When her husband came home and asked her whether she had kept her promise, she unhesitatingly said "Yes." 

But he saw by the flowers that she was telling a lie, and said, "Now I will not put your curiosity to the test any longer. Come with me. I will show you myself what is behind the door." 

Thereupon he led her to the door, opened it, gave her such a push that she fell down into hell, and shut the door again.

A few months after he wooed the next sister for his wife, and won her; but with her everything that had happened with the first wife was exactly repeated.

Finally he courted the third sister. She was a prudent maiden, and said to herself, "He has certainly murdered my two sisters; but then it is a splendid match for me, so I will try and see whether I cannot be more fortunate than they." 

And accordingly she consented. 

After the wedding the bridegroom gave her a beautiful bouquet, but forbade her, also, to open the door which he pointed out.

Not a whit less curious than her sisters, she, too, opened the forbidden door when the devil had gone hunting, but she had previously put her flowers in water. Then she saw behind the door the fatal abyss and her sisters therein. 

"Ah!" she exclaimed, "poor creature that I am; I thought I had married an ordinary man, and instead of that he is the devil! How can I get away from him?" 

She carefully pulled her two sisters out of hell and hid them. When the devil came home he immediately looked at the bouquet, which she again wore on her bosom, and when he found the flowers so fresh he asked no questions; but reassured as to his secret, he now, for the first time, really loved her.

After a few days she asked him if he would carry three chests for her to her parents' house, without putting them down or resting on the way. "But," she added, "you must keep your word, for I shall be watching you."

The devil promised to do exactly as she wished. So the next morning she put one of her sisters in a chest, and laid it on her husband's shoulders. The devil, who is very strong, but also very lazy and unaccustomed to work, soon got tired of carrying the heavy chest, and wanted to rest before he was out of the street on which he lived; but his wife called out to him, "Don't put it down; I see you!"

The devil went reluctantly on with the chest until he had turned the corner, and then said to himself, "She cannot see me here; I will rest a little."

But scarcely had he begun to put the chest down when the sister inside cried out, "Don't put it down; I see you still!" 

Cursing, he dragged the chest on into another street, and was going to lay it down on a doorstep, but he again heard the voice, "Don't lay it down, you rascal; I see you still!"

"What kind of eyes must my wife have," he thought, "to see around corners as well as straight ahead, and through walls as if they were made of glass!" and thus thinking he arrived, all in a perspiration and quite tired out, at the house of his mother-in-law, to whom he hastily delivered the chest, and then hurried home to strengthen himself with a good breakfast.

The same thing was repeated the next day with the second chest. On the third day she herself was to be taken home in the chest. She therefore prepared a figure which she dressed in her own clothes, and placed on the balcony, under the pretext of being able to watch him better; slipped quickly into the chest, and had the maid put it on the devil's back. 

"The deuce!" said he; "this chest is a great deal heavier than the others; and today, when she is sitting on the balcony, I shall have so much the less chance to rest." 

So by dint of the greatest exertions he carried it, without stopping, to his mother-in-law, and then hastened home to breakfast, scolding, and with his back almost broken.

But quite contrary to custom, his wife did not come out to meet him, and there was no breakfast ready. 

"Margerita, where are you?" he cried, but received no answer. As he was running through the corridors, he at length looked out of a window and saw the figure on the balcony. "Margerita, have you gone to sleep? Come down. I am as tired as a dog, and as hungry as a wolf." 

But there was no reply. 

"If you do not come down instantly I will go up and bring you down," he cried, angrily; but Margerita did not stir. 

Enraged, he hastened up to the balcony, and gave her such a box on the ear that her head flew off, and he saw that the head was nothing but a milliner's form, and the body, a bundle of rags. Raging, he rushed down and rummaged through the whole house, but in vain; he found only his wife's empty jewel box. 

"Ha!" he cried; "she has been stolen from me and her jewels, too!" and he immediately ran to inform her parents of the misfortune. 

But when he came near the house, to his great surprise he saw on the balcony above the door all three sisters, his wives, who were looking down on him with scornful laughter.

Three wives at once terrified the devil so much that he took his flight with all possible speed.

Since that time he has lost his taste for marrying.

Source: https://sites.pitt.edu/~dash/type0311.html